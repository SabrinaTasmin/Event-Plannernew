import { StrictMode } from 'react';
import { createRoot } from 'react-dom/client';
import './index.css';
import App from './App.jsx';
import { BrowserRouter, Routes, Route } from 'react-router-dom';
import Homepage from './components/Homepage.jsx';
import AdminLogin from './components/Admin.jsx';
import AdminDashboard from './components/AdminDashboard.jsx';
import AboutUs from './components/AboutUs.jsx';
import BirthdayEvents from './components/BirthdayEvents.jsx';
import ContactUs from './components/ContactUs.jsx';
import CorporateEvents from './components/CorporateEvents.jsx'


import WeddingEvents from './components/WeddingEvents.jsx';

createRoot(document.getElementById('root')).render(
  <StrictMode>
    <BrowserRouter>
      <Routes>
        <Route path="/" element={<Homepage />} />
        <Route path="/admin-login" element={<AdminLogin />} />
        <Route path="/admin-dashboard" element={<AdminDashboard />} /> 
        <Route path="/about-us" element={<AboutUs />} />
         <Route path="/birthday-events" element={<BirthdayEvents />} />
     <Route path="/contact-us" element={<ContactUs />} />
      <Route path="/wedding-events" element={<WeddingEvents />} />
      <Route path="/corporate-events" element={<CorporateEvents />} />

        
      </Routes>
    </BrowserRouter>
  </StrictMode>
);
