import React from 'react';
import { useNavigate } from 'react-router-dom'; // Import useNavigate

const AboutUs = () => {
  const navigate = useNavigate(); // Hook for navigation

  return (
    <>
      {/* About Us Section */}
      <section className="bg-white py-16 relative">
        {/* Home button */}
        <button
          onClick={() => navigate('/')} // Navigate to home page
          className="absolute top-4 right-4 bg-pink-600 text-white px-4 py-2 rounded-lg shadow-md hover:bg-pink-700 focus:outline-none transition duration-300"
        >
          Home
        </button>

        <div className="max-w-6xl mx-auto px-4">
          <h2 className="text-4xl font-bold text-center text-pink-600 mb-4">About Us</h2>
          <p className="text-center text-gray-600 max-w-2xl mx-auto mb-12">
            Learn more about who we are, what we do, and how we make every event a memorable experience.
          </p>

          <div className="flex flex-col md:flex-row md:space-x-10 items-center">
            <div className="md:w-1/2 mb-8 md:mb-0">
              <img
                src="https://eventcobd.com/wp-content/uploads/2024/03/conference-organisers.jpg"
                alt="About Eventify"
                className="rounded-xl shadow-lg w-full h-96 object-cover"
              />
            </div>

            <div className="md:w-1/2 space-y-6 bg-pink-50 p-6 rounded-xl shadow-sm">
              <p className="text-gray-700 text-lg">
                <span className="font-semibold text-pink-600">Eventify</span> is a passionate and experienced event
                management company based in Bangladesh. Our mission is to turn your personal and corporate events into
                unforgettable memories.
              </p>

              <p className="text-gray-700 text-md">
                We specialize in managing a wide range of events including seminars, trade shows, fashion shows,
                product launches, annual meetings, weddings, birthdays, and more. With a creative team, we provide
                custom event styling and flawless execution.
              </p>

              <p className="text-gray-700 text-md">
                As Dhaka continues to grow rapidly, Eventify ensures that your events stand out through reliability,
                creativity, and excellence. We operate across Bangladesh including Dhaka, Chittagong, and Cox’s Bazar.
              </p>

              <p className="text-gray-700 text-md">
                At Eventify, we treat every event as an opportunity to inspire and engage. From planning to delivery,
                we aim to create immersive experiences that reflect your vision and exceed expectations.
              </p>
            </div>
          </div>
        </div>
      </section>
    </>
  );
};

export default AboutUs;
