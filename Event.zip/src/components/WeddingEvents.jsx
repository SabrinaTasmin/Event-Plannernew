import React from 'react';
import { useNavigate } from 'react-router-dom';

const WeddingEvents = () => {
  const navigate = useNavigate();

  const packages = [
    { name: "Silver Package", price: "৳50,000", details: "Basic stage decoration, sound system, and photography." },
    { name: "Gold Package", price: "৳100,000", details: "Includes Silver + LED wall screen, flower decor, and buffet." },
    { name: "Platinum Package", price: "৳150,000", details: "Includes Gold + luxury car, guest management, fireworks." },
  ];

  const decorations = [
    "Stage Floral Setup",
    "LED Lights",
    "Photo Booth",
    "Entrance Arch",
    "Table Centerpieces"
  ];

  const venues = [
    {
      name: "Grand Palace Banquet Hall",
      price: "৳80,000",
      image: "https://images.unsplash.com/photo-1573164713988-8665fc963095"
    },
    {
      name: "Dream Garden Venue",
      price: "৳120,000",
      image: "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcTnd80CQUb_FsiZYWZN0KrTGHlo4C9Q1QmBoQ&s"
    },
    {
      name: "Skyline Rooftop",
      price: "৳100,000",
      image: "https://apis.xogrp.com/media-api/images/224907a0-b2f0-11ed-85d9-571c49b25940"
    },
    {
      name: "Royal Event Center",
      price: "৳90,000",
      image: "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcSDWJQVsEu8wv0Je6NLSEdlzWvSqlOK0W--Lg&s"
    },
    {
      name: "Luxury Garden Resort",
      price: "৳150,000",
      image: "https://www.arizonabiltmore.com/wp-content/uploads/2022/08/11-custom-1500x1001.jpg"
    },
    {
      name: "Crystal Ballroom Dhaka",
      price: "৳200,000",
      image: "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcREFhdd5G5dgGk1FaIzsaszILqaxZCOpvkQZ8GHDKwIE3SF0EDnhnmLKnESmH1QLBP8zYg&usqp=CAU"
    }
  ];

  const reviews = [
    { name: "Ayesha R.", review: "Our wedding was magical thanks to their flawless planning. Highly recommended!" },
    { name: "Tanvir H.", review: "Everything from the decor to the food was just perfect. Truly professional service." },
    { name: "Nusrat K.", review: "Loved the Dream Garden venue and the Gold package. Worth every penny!" },
  ];

  return (
    <div className="bg-pink-50 min-h-screen py-10 px-6">
      <div className="flex justify-end mb-6">
        <button
          onClick={() => navigate('/')}
          className="bg-pink-600 text-white px-5 py-2 rounded hover:bg-pink-700 transition"
        >
          Home
        </button>
      </div>

      {/* Intro Paragraph */}
      <div className="max-w-4xl mx-auto text-center mb-10">
        <p className="text-lg text-gray-700">
          At our event planning service, we believe weddings should be unforgettable, magical, and stress-free.
          Our expertly curated wedding packages offer everything from elegant decorations and premium venues
          to luxury experiences tailored to your unique love story. Whether you prefer a grand celebration
          or an intimate gathering, we handle every detail so you can focus on making memories that last a lifetime.
        </p>
      </div>

      <h2 className="text-4xl text-center font-bold text-pink-600 mb-10">Wedding Event Packages</h2>

      {/* Packages */}
      <div className="grid md:grid-cols-3 gap-6 mb-12">
        {packages.map((pkg, i) => (
          <div key={i} className="bg-white shadow rounded-lg p-6">
            <h3 className="text-xl font-bold text-pink-700 mb-2">{pkg.name}</h3>
            <p className="text-gray-600">{pkg.details}</p>
            <p className="text-pink-600 font-semibold mt-2">{pkg.price}</p>
          </div>
        ))}
      </div>

      {/* Decorations */}
      <div className="mb-12">
        <h3 className="text-2xl font-bold text-gray-800 mb-4">Decoration Add-Ons</h3>
        <ul className="list-disc list-inside text-gray-700 space-y-1">
          {decorations.map((item, i) => <li key={i}>{item}</li>)}
        </ul>
      </div>

      {/* Venues */}
      <div className="mb-12">
        <h3 className="text-2xl font-bold text-gray-800 mb-6">Wedding Venues</h3>
        <div className="grid sm:grid-cols-2 md:grid-cols-3 gap-6">
          {venues.map((venue, i) => (
            <div key={i} className="bg-white rounded shadow p-4 text-center">
              <img src={venue.image} alt={venue.name} className="h-40 w-full object-cover mb-3 rounded" />
              <h4 className="text-pink-700 font-semibold">{venue.name}</h4>
              <p className="text-gray-600">{venue.price}</p>
            </div>
          ))}
        </div>
      </div>

      {/* Customer Reviews */}
      <div className="mb-12">
        <h3 className="text-2xl font-bold text-gray-800 mb-6">Customer Reviews</h3>
        <div className="grid md:grid-cols-3 gap-6">
          {reviews.map((r, i) => (
            <div key={i} className="bg-white p-5 shadow rounded">
              <p className="italic text-gray-700 mb-2">"{r.review}"</p>
              <p className="text-sm font-semibold text-pink-600 text-right">– {r.name}</p>
            </div>
          ))}
        </div>
      </div>

      {/* Booking Button */}
      <section className="py-16 bg-pink-100">
        <div className="max-w-4xl mx-auto px-4 text-center">
          <h2 className="text-3xl font-bold text-pink-700 mb-6">Want to Book Your Event?</h2>
          <p className="text-gray-700 mb-4">Contact us via phone or WhatsApp to plan your perfect birthday celebration.</p>

          <div className="space-y-2 text-lg font-medium">
            <p>📞 Phone: <a href="tel:+880123456789" className="text-pink-700 underline">01754650711</a></p>
            <p>💬 WhatsApp: <a href="https://wa.me/880123456789?text=Hi%2C%20I%20want%20to%20book%20a%20birthday%20event" target="_blank" rel="noopener noreferrer" className="text-pink-700 underline">Message on WhatsApp</a></p>
          </div>
        </div>
      </section>
    </div>
  );
};

export default WeddingEvents;
