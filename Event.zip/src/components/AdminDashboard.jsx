import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { Calendar, momentLocalizer } from 'react-big-calendar';
import moment from 'moment';
import 'react-big-calendar/lib/css/react-big-calendar.css';

const localizer = momentLocalizer(moment);

const AdminDashboard = () => {
  const navigate = useNavigate();

  // Calendar State
  const [events, setEvents] = useState([]);
  const [eventName, setEventName] = useState('');
  const [clientName, setClientName] = useState('');
  const [clientNumber, setClientNumber] = useState('');
  const [eventDate, setEventDate] = useState('');
  const [eventTime, setEventTime] = useState('');

  // Messages State
  const [messages, setMessages] = useState([]);

  useEffect(() => {
    const storedMessages = JSON.parse(localStorage.getItem('contactMessages')) || [];
    setMessages(storedMessages);
  }, []);

  const handleAddEvent = () => {
    if (!eventName || !clientName || !clientNumber || !eventDate || !eventTime) {
      alert('Please fill all fields!');
      return;
    }

    const newEvent = {
      title: eventName,
      start: new Date(`${eventDate}T${eventTime}:00`),
      end: new Date(`${eventDate}T${eventTime}:00`),
      clientName,
      clientNumber,
    };

    setEvents([...events, newEvent]);

    setEventName('');
    setClientName('');
    setClientNumber('');
    setEventDate('');
    setEventTime('');
  };

  const handleDeleteEvent = (eventToDelete) => {
    setEvents(events.filter((event) => event !== eventToDelete));
  };

  const handleDeleteMessage = (indexToDelete) => {
    const updatedMessages = messages.filter((_, index) => index !== indexToDelete);
    setMessages(updatedMessages);
    localStorage.setItem('contactMessages', JSON.stringify(updatedMessages));
  };

  const handleDoneMessage = (indexToMark) => {
    const updatedMessages = messages.map((msg, index) =>
      index === indexToMark ? { ...msg, done: true } : msg
    );
    setMessages(updatedMessages);
    localStorage.setItem('contactMessages', JSON.stringify(updatedMessages));
  };

  return (
    <div className="min-h-screen bg-pink-100 p-6">
      <div className="flex justify-between items-center mb-8">
        <h1 className="text-3xl font-bold text-pink-600">Admin Dashboard</h1>
        <button
          onClick={() => navigate('/')}
          className="bg-pink-600 text-white px-4 py-2 rounded hover:bg-pink-700"
        >
          Back to Homepage
        </button>
      </div>

      {/* Calendar Management Section */}
      <div className="bg-white p-6 rounded-lg shadow-md mb-12">
        <h2 className="text-2xl font-semibold text-gray-800 mb-4">Event Management</h2>
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 mb-4">
          <input placeholder="Event Name" value={eventName} onChange={(e) => setEventName(e.target.value)} className="border px-4 py-2 rounded" />
          <input placeholder="Client Name" value={clientName} onChange={(e) => setClientName(e.target.value)} className="border px-4 py-2 rounded" />
          <input placeholder="Client Number" value={clientNumber} onChange={(e) => setClientNumber(e.target.value)} className="border px-4 py-2 rounded" />
          <input type="date" value={eventDate} onChange={(e) => setEventDate(e.target.value)} className="border px-4 py-2 rounded" />
          <input type="time" value={eventTime} onChange={(e) => setEventTime(e.target.value)} className="border px-4 py-2 rounded" />
        </div>
        <button
          onClick={handleAddEvent}
          className="bg-pink-600 text-white w-full py-2 rounded hover:bg-pink-700 mb-6"
        >
          Add Event
        </button>

        <Calendar
          localizer={localizer}
          events={events}
          startAccessor="start"
          endAccessor="end"
          style={{ height: 500 }}
          views={['month', 'week', 'day']}
          onSelectEvent={(event) => {
            if (window.confirm('Do you want to delete this event?')) {
              handleDeleteEvent(event);
            }
          }}
        />
      </div>

      {/* Display Events List */}
      {events.length > 0 && (
        <div className="bg-white p-6 rounded-lg shadow-md mb-12">
          <h3 className="text-xl font-semibold text-gray-800 mb-4">Added Events</h3>
          {events.map((event, index) => (
            <div key={index} className="border-b py-2">
              <p className="text-pink-700 font-semibold">{event.title}</p>
              <p className="text-gray-600">Client: {event.clientName}</p>
              <p className="text-gray-600">Number: {event.clientNumber}</p>
              <p className="text-gray-600">Date: {moment(event.start).format('LL')}</p>
              <p className="text-gray-600">Time: {moment(event.start).format('h:mm A')}</p>
            </div>
          ))}
        </div>
      )}

      {/* Messages Section */}
      <div className="bg-white p-6 rounded-lg shadow-md">
        <h2 className="text-2xl font-semibold text-pink-600 mb-6">Received Messages</h2>
        {messages.length === 0 ? (
          <p className="text-gray-500">No messages yet.</p>
        ) : (
          messages.map((msg, index) => (
            <div
              key={index}
              className={`p-4 rounded shadow mb-4 ${msg.done ? 'bg-gray-100' : 'bg-pink-50'}`}
            >
              <h4 className={`font-semibold ${msg.done ? 'text-gray-400' : 'text-pink-700'}`}>
                {msg.name} ({msg.email})
              </h4>
              <p className={`mt-2 ${msg.done ? 'text-gray-400' : 'text-gray-700'}`}>{msg.message}</p>
              <div className="mt-4 flex gap-2">
                <button
                  onClick={() => handleDeleteMessage(index)}
                  className="bg-red-500 text-white px-3 py-1 rounded hover:bg-red-600 transition disabled:opacity-50"
                  disabled={msg.done}
                >
                  Delete
                </button>
                <button
                  onClick={() => handleDoneMessage(index)}
                  className="bg-green-500 text-white px-3 py-1 rounded hover:bg-green-600 transition disabled:opacity-50"
                  disabled={msg.done}
                >
                  Done
                </button>
              </div>
            </div>
          ))
        )}
      </div>
    </div>
  );
};

export default AdminDashboard;
