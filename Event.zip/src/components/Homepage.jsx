import { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';

const Homepage = () => {
  const navigate = useNavigate();
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);
  const [currentImageIndex, setCurrentImageIndex] = useState(0);

  const images = [
    "https://images.unsplash.com/photo-1602631985686-1bb0e6a8696e?q=80&w=1470&auto=format&fit=crop&ixlib",
    "https://images.unsplash.com/photo-1670213193254-cbbebedfe8b9?q=80&w=1470&auto=format&fit=crop&ixlib",
    "https://images.unsplash.com/photo-1736155983520-a0f7d5949d39?w=500&auto=format&fit=crop&q=60&ixlib"
  ];

  useEffect(() => {
    const interval = setInterval(() => {
      setCurrentImageIndex(prevIndex => (prevIndex + 1) % images.length);
    }, 4000); // 4 seconds
    return () => clearInterval(interval);
  }, [images.length]);

  return (
    <>
      {/* Navbar */}
      <nav className="bg-white shadow-md">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between h-16 items-center">
            <div className="text-2xl font-bold text-pink-600">Eventify</div>
            <div className="hidden md:flex space-x-6 items-center">
              <a href="#" className="text-blue-500 hover:text-pink-600">Home</a>
               
              <div className="relative group">
                <button className="text-blue-500 hover:text-pink-600">Event Equipment Rental</button>
                <div className="absolute hidden group-hover:block bg-white shadow-lg rounded-md mt-2 w-48 z-10">
                  <button className="block w-full text-left px-4 py-2 text-blue-500 hover:bg-pink-100">Projector Rental</button>
                  <button className="block w-full text-left px-4 py-2 text-blue-500 hover:bg-pink-100">LED Wall Screen</button>
                  <button className="block w-full text-left px-4 py-2 text-blue-500 hover:bg-pink-100">Sound System</button>
                </div>
              </div>

              <button
                onClick={() => navigate('corporate-events')}
                className="text-blue-500 hover:text-pink-600 font-semibold"
              >
                CorporateEvents
              </button>

              <button
                onClick={() => navigate('/wedding-events')}
                className="text-blue-500 hover:text-pink-600 font-semibold"
              >
                WeddingEvents
              </button>
              <button
                onClick={() => navigate('/birthday-events')}
                className="text-blue-500 hover:text-pink-600 font-semibold"
              >
                BirthdayEvents
              </button>
              <button
                onClick={() => navigate('/contact-us')}
                className="text-blue-500 hover:text-pink-600 font-semibold"
              >
                ContactUs
              </button>
            
              
              <button
                onClick={() => navigate('/about-us')}
                className="text-blue-500 hover:text-pink-600 font-semibold"
              >
                AboutUs
              </button>

              <button
                onClick={() => navigate('/admin-login')}
                className="text-blue-500 hover:text-pink-600 font-semibold"
              >
                Admin
              </button>
             
             
           
            </div>

            <div className="md:hidden">
              <button onClick={() => setIsMobileMenuOpen(!isMobileMenuOpen)} className="text-gray-700 focus:outline-none">
                <svg className="h-6 w-6" fill="none" stroke="currentColor" strokeWidth="2"
                  viewBox="0 0 24 24" strokeLinecap="round" strokeLinejoin="round">
                  <path d="M4 6h16M4 12h16M4 18h16" />
                </svg>
              </button>
            </div>
          </div>
        </div>
      </nav>

      {/* Hero Section with Slideshow */}
      <section className="bg-pink-50 py-20">
        <div className="max-w-7xl mx-auto px-4 flex flex-col md:flex-row items-center justify-between">
          <div className="md:w-1/2 mb-10 md:mb-0">
            <h1 className="text-4xl md:text-5xl font-bold text-gray-800 mb-4">
              Plan Your Perfect Event with <span className="text-pink-600">Eventify</span>
            </h1>
            <p className="text-lg text-gray-600 mb-6">
              From weddings to birthdays, and top-quality equipment rental – we make your special moments unforgettable.
            </p>
            <a href="#" className="inline-block bg-pink-600 text-white px-6 py-3 rounded-lg shadow hover:bg-pink-700 transition duration-300">
              Explore Services
            </a>
          </div>
          <div className="md:w-1/2">
            <img
              src={images[currentImageIndex]}
              alt="Event Showcase"
              className="rounded-lg shadow-md h-80 w-full object-cover transition-all duration-1000"
            />
          </div>
        </div>
      </section>

      {/* Popular Items */}
      <section className="bg-white py-16">
        <div className="max-w-7xl mx-auto px-4">
          <h2 className="text-3xl font-bold text-center text-gray-800 mb-10">Our Popular Event Items</h2>
          <div className="grid gap-8 sm:grid-cols-2 md:grid-cols-3">
            {[
              {
                title: "LED Wall Screen",
                img: "https://images.unsplash.com/photo-1597333936102-0d9f997042ec?q=80&w=1470&auto=format&fit=crop&ixlib"
              },
              {
                title: "GhoraGari",
                img: "https://images.unsplash.com/photo-1664006985194-50bd5d2b859d?q=80&w=1374&auto=format&fit=crop&ixlib"
              },
              {
                title: "Palki",
                img: "https://i0.wp.com/decorsutrablog.com/wp-content/uploads/2020/05/Decorsutra_Palki-Bridal-Entry_fairytale-Weddings.jpg?fit=1072%2C1171&ssl=1"
              },
              {
                title: "Sound System",
                img: "https://images.unsplash.com/photo-1629096193181-89aa83f523cb?q=80&w=1428&auto=format&fit=crop&ixlib"
              },
              {
                title: "Birthday Decoration",
                img: "https://plus.unsplash.com/premium_photo-1663090585707-96572044e509?q=80&w=1470&auto=format&fit=crop&ixlib"
              }
            ].map((item, index) => (
              <div key={index} className="bg-pink-50 rounded-lg shadow-md overflow-hidden">
                <img src={item.img} alt={item.title} className="h-48 w-full object-cover" />
                <div className="p-4">
                  <h3 className="text-lg font-semibold text-pink-600">{item.title}</h3>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Customer Reviews */}
      <section className="bg-pink-100 py-16">
        <div className="max-w-5xl mx-auto px-4 text-center">
          <h2 className="text-3xl font-bold text-gray-800 mb-10">What Our Customers Say</h2>
          <div className="grid gap-6 md:grid-cols-3">
            {[
              {
                name: "Sarah Ahmed",
                review: "The decorations for my wedding were absolutely stunning! Everyone was impressed."
              },
              {
                name: "Rafiq Islam",
                review: "Very professional team and excellent sound system for our corporate event!"
              },
              {
                name: "Maya Khatun",
                review: "I loved the birthday setup for my daughter. The team did an amazing job!"
              }
            ].map((customer, i) => (
              <div key={i} className="bg-white rounded-lg shadow p-6">
                <p className="text-gray-600 mb-4">“{customer.review}”</p>
                <h4 className="text-pink-600 font-semibold">{customer.name}</h4>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Footer */}
      <footer className="bg-gray-800 text-white py-8">
        <div className="max-w-7xl mx-auto px-4 text-center">
          <p className="mb-2">📍 Address: House-32, 5th Floor, Road-Pirerbag, Shewrapara, Dhaka</p>
          <p>📧 Email: <a href="mailto:SabrinaMoon@gmail.com" className="underline hover:text-pink-400">SabrinaMoon@gmail.com</a></p>
          <p className="mt-4 text-sm text-gray-400">© {new Date().getFullYear()} Eventify. All rights reserved.</p>
        </div>
      </footer>
    </>
  );
};

export default Homepage;
