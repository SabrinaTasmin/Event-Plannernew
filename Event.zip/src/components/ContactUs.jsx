import React, { useState } from 'react';
import { FaPhoneAlt, FaWhatsapp, FaMapMarkerAlt } from 'react-icons/fa';
import { useNavigate } from 'react-router-dom';

const ContactUs = () => {
  const navigate = useNavigate();
  const [formData, setFormData] = useState({
    name: '',
    email: '',
    message: ''
  });

  const handleChange = (e) => {
    setFormData(prev => ({ ...prev, [e.target.name]: e.target.value }));
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    const messages = JSON.parse(localStorage.getItem('contactMessages')) || [];
    messages.push(formData);
    localStorage.setItem('contactMessages', JSON.stringify(messages));
    alert('Message sent successfully!');
    setFormData({ name: '', email: '', message: '' });
  };

  return (
    <div className="min-h-screen bg-pink-50 py-16 px-4">
      <div className="max-w-6xl mx-auto">
        {/* Header with Back Button */}
        <div className="flex justify-between items-center mb-12">
          <h2 className="text-4xl font-bold text-pink-600">Contact Us</h2>
          <button
            onClick={() => navigate('/')}
            className="bg-pink-500 text-white px-4 py-2 rounded hover:bg-pink-600 transition"
          >
            Back to Home
          </button>
        </div>

        {/* Contact Info */}
        <div className="grid md:grid-cols-2 gap-12 mb-16">
          <div className="space-y-6">
            <div className="flex items-start space-x-4">
              <FaMapMarkerAlt className="text-pink-600 text-2xl mt-1" />
              <div>
                <h4 className="text-lg font-semibold text-pink-700">Our Location</h4>
                <p className="text-gray-700">House-32, 5th Floor, Road-Pirerbag, Shewrapara, Dhaka</p>
              </div>
            </div>
            <div className="flex items-start space-x-4">
              <FaPhoneAlt className="text-pink-600 text-2xl mt-1" />
              <div>
                <h4 className="text-lg font-semibold text-pink-700">Phone</h4>
                <p className="text-gray-700">+880 1234 567890</p>
              </div>
            </div>
            <div className="flex items-start space-x-4">
              <FaWhatsapp className="text-green-600 text-2xl mt-1" />
              <div>
                <h4 className="text-lg font-semibold text-green-700">WhatsApp</h4>
                <p className="text-gray-700">+880 1987 654321</p>
              </div>
            </div>
          </div>

          {/* Google Map */}
          <div className="w-full h-64 md:h-full">
            <iframe
              className="w-full h-full rounded-lg shadow-lg"
              title="Google Map"
              src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3648.926770124956!2d90.3842533!3d23.7573548!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x3755bf54c2ee85e1%3A0x58f74598f36d7741!2sDhaka!5e0!3m2!1sen!2sbd!4v1681293478304!5m2!1sen!2sbd"
              allowFullScreen=""
              loading="lazy"
              referrerPolicy="no-referrer-when-downgrade"
            ></iframe>
          </div>
        </div>

        {/* Contact Form */}
        <div className="bg-white p-8 rounded-lg shadow-md max-w-2xl mx-auto">
          <h3 className="text-2xl font-semibold text-pink-600 mb-4 text-center">Send Us a Message</h3>
          <form onSubmit={handleSubmit} className="space-y-4">
            <div>
              <label className="block text-gray-700 font-medium mb-1">Name</label>
              <input
                type="text"
                name="name"
                value={formData.name}
                onChange={handleChange}
                className="w-full border border-gray-300 p-2 rounded"
                required
              />
            </div>
            <div>
              <label className="block text-gray-700 font-medium mb-1">Email</label>
              <input
                type="email"
                name="email"
                value={formData.email}
                onChange={handleChange}
                className="w-full border border-gray-300 p-2 rounded"
                required
              />
            </div>
            <div>
              <label className="block text-gray-700 font-medium mb-1">Message</label>
              <textarea
                name="message"
                rows="4"
                value={formData.message}
                onChange={handleChange}
                className="w-full border border-gray-300 p-2 rounded"
                required
              />
            </div>
            <button
              type="submit"
              className="bg-pink-600 text-white px-6 py-2 rounded-full hover:bg-pink-700 transition w-full"
            >
              Send Message
            </button>
          </form>
        </div>
      </div>
    </div>
  );
};

export default ContactUs;
