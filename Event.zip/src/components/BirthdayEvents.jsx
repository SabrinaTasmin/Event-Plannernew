import React from 'react';
import { useNavigate } from 'react-router-dom';

const BirthdayEvents = () => {
  const navigate = useNavigate();

  const handleHomeClick = () => {
    navigate('/');
  };

  return (
    <>
      {/* Home Button */}
      <div className="flex justify-end px-6 pt-6">
        <button
          onClick={handleHomeClick}
          className="bg-pink-600 text-white px-4 py-2 rounded-full shadow hover:bg-pink-700 transition"
        >
          Home
        </button>
      </div>

      {/* Birthday Event Packages Section */}
      <section className="py-16 bg-pink-50">
        <div className="max-w-6xl mx-auto px-4">
          <h2 className="text-4xl font-bold text-center text-pink-600 mb-6">Our Birthday Event Packages</h2>

          <p className="text-center text-gray-700 max-w-3xl mx-auto mb-12 text-lg">
            Birthday parties are joyful milestones meant to be celebrated with creativity and excitement. Whether it's a child's first birthday or an adult’s grand celebration, we provide themed decorations, entertainment, custom cakes, and full-service event planning. Let us help you make unforgettable birthday memories with elegance, color, and joy tailored to your needs.
          </p>

          <div className="grid gap-8 sm:grid-cols-2 md:grid-cols-3">
            {[
              {
                title: "Basic Birthday Package",
                price: "৳5,000",
                description: "Simple decorations, cake, and seating.",
                items: ["Backdrop with balloons", "Basic lighting", "1 Birthday Cake", "10 Chairs"],
                img: "https://www.larisarealtech.com/wp-content/uploads/2024/03/1-6.webp"
              },
              {
                title: "Deluxe Birthday Package",
                price: "৳12,000",
                description: "Theme decor, music setup, cake, and seating.",
                items: ["Themed balloon decor", "Cake table decor", "Speaker system", "15 Chairs", "Photobooth"],
                img: "https://www.borstlandscape.com/wp-content/uploads/2020/03/emmanuel-mwape-un2jmxLaYFY-unsplash.jpg"
              },
              {
                title: "Luxury Birthday Package",
                price: "৳25,000",
                description: "Designer cake, DJ, stage lighting, catering.",
                items: ["Designer cake", "Full venue decor", "Stage lighting", "DJ & Mic", "20+ seating", "Buffet catering"],
                img: "https://woogle.co.in/cdn/shop/files/WhatsAppImage2024-02-09at1.03.00PM.jpg?v=1707464024&width=1946"
              }
            ].map((item, index) => (
              <div key={index} className="bg-white rounded-lg shadow-md overflow-hidden">
                <img src={item.img} alt={item.title} className="h-48 w-full object-cover" />
                <div className="p-4 space-y-2">
                  <h3 className="text-xl font-semibold text-pink-600">{item.title}</h3>
                  <p className="text-gray-700">{item.description}</p>
                  <p className="font-bold text-gray-800">Price: {item.price}</p>
                  <ul className="list-disc list-inside text-gray-600 text-sm">
                    {item.items.map((i, idx) => (
                      <li key={idx}>{i}</li>
                    ))}
                  </ul>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Cake Decoration Options */}
      <section className="py-16 bg-white">
        <div className="max-w-6xl mx-auto px-4">
          <h2 className="text-3xl font-bold text-center text-pink-600 mb-10">Cake Decoration Options</h2>

          <div className="grid gap-8 sm:grid-cols-2 md:grid-cols-3">
            {[
              {
                title: "Princess Theme Cake",
                price: "৳2,500",
                img: "https://yummycake.in/wp-content/uploads/2024/01/disney-princess-theme-cake-1.jpg"
              },
              {
                title: "Cartoon Character Cake",
                price: "৳2,000",
                img: "https://assets.winni.in/product/primary/2014/6/33976.jpeg?dpr=2&w=220"
              },
              {
                title: "Rainbow Layer Cake",
                price: "৳2,800",
                img: "https://cdn.mos.cms.futurecdn.net/FxbABLKToMJ5oxuxfjrjtn.jpg"
              },
              {
                title: "Chocolate Fantasy Cake",
                price: "৳3,000",
                img: "https://xokatierosario.com/wp-content/uploads/2021/01/Dark_Chocolate_Truffle_Cake_cake_title_image_3_xokatierosario.com_.jpg"
              },
              {
                title: "Minimalist Modern Cake",
                price: "৳2,200",
                img: "https://i.pinimg.com/736x/5b/92/98/5b92985fa406a1fcc1c24edfcd28a63e.jpg"
              }
            ].map((cake, index) => (
              <div key={index} className="bg-pink-50 rounded-lg shadow-md overflow-hidden">
                <img src={cake.img} alt={cake.title} className="h-48 w-full object-cover" />
                <div className="p-4">
                  <h3 className="text-lg font-semibold text-pink-600">{cake.title}</h3>
                  <p className="text-gray-700 font-medium">Price: {cake.price}</p>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Completed Birthday Events Section */}
      <section className="py-16 bg-pink-50">
        <div className="max-w-6xl mx-auto px-4">
          <h2 className="text-4xl font-bold text-center text-pink-600 mb-12">Completed Birthday Events</h2>

          <div className="grid gap-8 sm:grid-cols-2 md:grid-cols-3">
            {[
              {
                title: "Sarah's 1st Birthday",
                img: "https://www.nijolcreative.com/wp-content/uploads/2023/07/14589745_913941252045686_8761419010721660492_o.jpg"
              },
              {
                title: "Rafiq's 25th Birthday",
                img: "https://cdn.giftlaya.com/images/a2c323bf-683a-4537-b83c-dd53e0bd575d/73dafef8-0933-40bd-896b-4c7e1ef58805.webp"
              },
              {
                title: "Maya's Sweet 16",
                img: "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcRTUJBAlSjAhTH0ayOnFAxx6Eih6P9ub-2a_nprLBdwF0T5YEsOpFE_v9MnQoEvqAX1BqQ&usqp=CAU"
              }
            ].map((event, index) => (
              <div key={index} className="bg-white rounded-lg shadow-md overflow-hidden">
                <img src={event.img} alt={event.title} className="h-48 w-full object-cover" />
                <div className="p-4">
                  <h3 className="text-lg font-semibold text-pink-600">{event.title}</h3>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Client Reviews Section */}
      <section className="py-16 bg-white">
        <div className="max-w-6xl mx-auto px-4">
          <h2 className="text-3xl font-bold text-center text-pink-600 mb-10">Client Reviews</h2>

          <div className="grid gap-8 sm:grid-cols-1 md:grid-cols-2 lg:grid-cols-3">
            {[
              {
                name: "Sarah's Parents",
                review: "Absolutely loved the setup for Sarah’s 1st birthday. Everything was well organized and beautiful!",
                img: "https://randomuser.me/api/portraits/women/68.jpg"
              },
              {
                name: "Rafiq",
                review: "My 25th birthday party was a blast! The DJ and decoration were top-notch. Highly recommend.",
                img: "https://randomuser.me/api/portraits/men/45.jpg"
              },
              {
                name: "Maya",
                review: "Loved my sweet 16 decor! It felt magical. Thank you for making my day special!",
                img: "https://randomuser.me/api/portraits/women/50.jpg"
              }
            ].map((client, index) => (
              <div key={index} className="bg-pink-50 rounded-lg shadow-md p-6 flex flex-col items-center text-center">
                <img src={client.img} alt={client.name} className="w-16 h-16 rounded-full mb-4 object-cover" />
                <h4 className="text-lg font-semibold text-pink-600">{client.name}</h4>
                <p className="text-gray-700 mt-2 text-sm italic">"{client.review}"</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Contact Section */}
      <section className="py-16 bg-pink-100">
        <div className="max-w-4xl mx-auto px-4 text-center">
          <h2 className="text-3xl font-bold text-pink-700 mb-6">Want to Book Your Event?</h2>
          <p className="text-gray-700 mb-4">Contact us via phone or WhatsApp to plan your perfect birthday celebration.</p>

          <div className="space-y-2 text-lg font-medium">
            <p>📞 Phone: <a href="tel:+880123456789" className="text-pink-700 underline">01754650711</a></p>
            <p>💬 WhatsApp: <a href="https://wa.me/880123456789?text=Hi%2C%20I%20want%20to%20book%20a%20birthday%20event" target="_blank" rel="noopener noreferrer" className="text-pink-700 underline">Message on WhatsApp</a></p>
          </div>
        </div>
      </section>
    </>
  );
};

export default BirthdayEvents;
